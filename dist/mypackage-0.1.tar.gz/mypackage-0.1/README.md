# mypackage
This library is a tutorial I am following on how to publish
 a python package onto github